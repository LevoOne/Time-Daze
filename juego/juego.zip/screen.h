/*
 * screen.h - Sistema de pantallas de Tempus Fugit
 */

#ifndef SCREEN_SYS_H
#define SCREEN_SYS_H

#include "game.h"

/* Datos de la pantalla actual, accesibles desde player.c */
extern ScreenData g_screen_data;

/* Spritesheet de Eric, cargado en screen_init */
extern BITMAP g_spritesheet;
extern BITMAP g_rock_sprite;
extern BITMAP g_shaman_sprite;
extern BITMAP g_stick_sprite;
extern BITMAP g_stick_icon;
extern BITMAP g_egg_sprite;
extern BITMAP g_egg_icon;

/* ----------------------------------------------------------------
 * FUNCIONES
 * ---------------------------------------------------------------- */

/* -----------------------------------------------------------------------------------------
 * screen_init()
 *   Inicializa el sistema de pantallas y carga el spritesheet de Eric.
 * Entrada: ninguna
 * Salida:  ninguna
 * -----------------------------------------------------------------------------------------*/
void screen_init(void);

/* -----------------------------------------------------------------------------------------
 * screen_load()
 *   Carga los datos de una pantalla concreta: plataformas y BMP de fondo.
 *   Actualiza g_screen_data y g_game.screen.
 * Entrada: epoch  (int) = epoca a cargar (EPOCH_*)
 *          screen (int) = pantalla a cargar (0..8)
 * Salida:  ninguna
 * -----------------------------------------------------------------------------------------*/
void screen_load(int epoch, int screen);

/* -----------------------------------------------------------------------------------------
 * screen_apply_palette()
 *   Aplica la paleta de la pantalla actual al hardware VGA directamente.
 *   Usar al arrancar o cargar partida, cuando no hay transicion de fade.
 * Entrada: ninguna
 * Salida:  ninguna
 * -----------------------------------------------------------------------------------------*/
void screen_apply_palette(void);

/* -----------------------------------------------------------------------------------------
 * screen_draw()
 *   Dibuja el BMP de fondo de la pantalla actual en el back buffer.
 * Entrada: ninguna
 * Salida:  ninguna
 * -----------------------------------------------------------------------------------------*/
void screen_draw(void);

/* -----------------------------------------------------------------------------------------
 * screen_draw_rock()
 *   Dibuja el sprite de la roca en P1 de Prehistoria si PUZZLE_LEVER no esta resuelto.
 * Entrada: ninguna
 * Salida:  ninguna
 * -----------------------------------------------------------------------------------------*/
void screen_draw_rock(void);

/* -----------------------------------------------------------------------------------------
 * screen_draw_shaman()
 *   Dibuja el chaman animado en P1 de Prehistoria sobre el dolmen izquierdo.
 * Entrada: ninguna
 * Salida:  ninguna
 * -----------------------------------------------------------------------------------------*/
void screen_draw_shaman(void);

/* -----------------------------------------------------------------------------------------
 * screen_change()
 *   Gestiona el cambio de pantalla en una direccion con fade.
 *   Comprueba conexiones y bloqueos por puzzles.
 * Entrada: dir (int) = direccion del cambio (DIR_*)
 * Salida:  1 si hay conexion y se ha cambiado, 0 si no hay conexion
 * -----------------------------------------------------------------------------------------*/
int screen_change(int dir);

/* -----------------------------------------------------------------------------------------
 * screen_travel()
 *   Gestiona el viaje temporal a otra epoca con fade.
 *   Mantiene la misma pantalla en la nueva epoca.
 * Entrada: new_epoch (int) = epoca destino (EPOCH_*)
 * Salida:  ninguna
 * -----------------------------------------------------------------------------------------*/
void screen_travel(int new_epoch);

/* -----------------------------------------------------------------------------------------
 * screen_get_connection()
 *   Devuelve la pantalla conectada en una direccion, teniendo en cuenta
 *   los bloqueos por puzzles.
 * Entrada: dir (int) = direccion a consultar (DIR_*)
 * Salida:  indice de pantalla conectada (0..8), o NO_SCREEN si no hay conexion
 * -----------------------------------------------------------------------------------------*/
int screen_get_connection(int dir);

#endif /* SCREEN_SYS_H */
